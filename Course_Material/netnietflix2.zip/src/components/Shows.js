
import useFetch from "./useFetch";
import noImage from "../img/noImageAvailable.jpg";


export default function Shows(props) {

    const data = useFetch(`https://api.themoviedb.org/3/tv/${props.showId}`);

    if (data !== undefined) {        
        const poster = data.poster_path === undefined || data.poster_path === null ? noImage : "https://image.tmdb.org/t/p/w500" + data.poster_path;

        return (
            <div>
                <img src={poster} alt={data.name}></img>
                <h3>{data.name}</h3>
                <p>{data.last_air_date}</p>
            </div>
        );
    }
    else {
        return (<></>);
    }
}

