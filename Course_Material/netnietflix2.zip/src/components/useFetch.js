import axios from "axios";
import { useEffect, useState } from "react";

const useFetch = (param) => {
    const [data, setData] = useState([]);

    useEffect(() => {
        // declare the data fetching function
        const apiKey = "dc4814a4cf8e958afe5a79c74bbae395";
        let url = `${param}?api_key=${apiKey}&language=en-US`;

        axios
            .get(url)
            .then((response) => { setData(response.data); })
            .catch((error) => console.log(error));
    }, [param]);

    return data;
};

export default useFetch;
