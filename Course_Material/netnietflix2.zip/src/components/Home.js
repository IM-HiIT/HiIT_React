import useFetch from "./useFetch";
import Carousel from "nuka-carousel";
import Shows from './Shows';
import { useState } from 'react';
import Logo from '../img/netnietflix.png'


export default function Netnietflix() {

    // Get top 20 of populair tv shows
    const data = useFetch("https://api.themoviedb.org/3/tv/popular");

    
    return (
        <>
        <img className="logo" alt="netnietflix" src={Logo} />
            <div className="carousel">
                <h1>Popular TV Shows</h1>
                <Carousel slidesToShow={5} wrapAround={true}>
                    {
                        (data.results || []).map((episode, index) => (
                            <Shows key={index} showId={episode.id}/>
                        ))
                    }
                </Carousel>
                <br />
            </div>
        </>
    );
}
